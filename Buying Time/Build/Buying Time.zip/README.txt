Instructions:
Unzip the folder associated with your operating system (Windows or Mac)
Run the ".exe"(win) or ".app"(mac) (the one with the pen icon) in this unzipped folderto play.

Press WASD to move in game and press space to use your weapon.

The Buying Upgrade sign does not work, we were going to have a paper economy to purchase upgrades and weapons but couldn't get it working

Project Teammates
~~~~~~~~~~~~~~~~~
Reid Jackson
Morgan O'Brien
